from flask import Blueprint, request, jsonify
import requests
import xml.etree.ElementTree as ET
from decimal import Decimal

shipping_bp = Blueprint('shipping', __name__)

# Configurações dos Correios
CORREIOS_BASE_URL = "http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx"
CORREIOS_CEP_ORIGEM = "37115000"  # Monte Belo, MG

# Códigos de serviços dos Correios
SERVICOS_CORREIOS = {
    'PAC': '04510',
    'SEDEX': '04014',
    'SEDEX_10': '04790',
    'SEDEX_HOJE': '04804'
}

def calcular_peso_produto(items):
    """Calcular peso total dos produtos (estimativa)"""
    peso_total = 0
    for item in items:
        # Peso estimado por tipo de produto (em kg)
        categoria = item.get('category', {}).get('slug', '')
        quantidade = item.get('quantity', 1)
        
        if categoria == 'tees':
            peso_total += 0.2 * quantidade  # 200g por camiseta
        elif categoria == 'hoodies':
            peso_total += 0.6 * quantidade  # 600g por moletom
        elif categoria == 'jackets':
            peso_total += 0.8 * quantidade  # 800g por jaqueta
        elif categoria == 'pants':
            peso_total += 0.5 * quantidade  # 500g por calça
        elif categoria == 'accessories':
            peso_total += 0.1 * quantidade  # 100g por acessório
        else:
            peso_total += 0.3 * quantidade  # Peso padrão
    
    return max(peso_total, 0.1)  # Peso mínimo de 100g

def calcular_dimensoes_pacote(items):
    """Calcular dimensões do pacote baseado nos itens"""
    # Dimensões padrão em cm
    comprimento = 20
    largura = 15
    altura = 5
    
    # Ajustar baseado na quantidade de itens
    total_items = sum(item.get('quantity', 1) for item in items)
    
    if total_items > 1:
        altura += (total_items - 1) * 2
    
    # Limites dos Correios
    comprimento = min(comprimento, 105)
    largura = min(largura, 105)
    altura = min(altura, 105)
    
    return comprimento, largura, altura

@shipping_bp.route('/shipping/calculate', methods=['POST'])
def calculate_shipping():
    """Calcular frete usando API dos Correios"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Dados não fornecidos'
            }), 400
        
        cep_destino = data.get('cep_destino', '').replace('-', '').replace('.', '')
        items = data.get('items', [])
        
        if not cep_destino or len(cep_destino) != 8:
            return jsonify({
                'success': False,
                'error': 'CEP de destino inválido'
            }), 400
        
        if not items:
            return jsonify({
                'success': False,
                'error': 'Itens do carrinho não fornecidos'
            }), 400
        
        # Calcular peso e dimensões
        peso = calcular_peso_produto(items)
        comprimento, largura, altura = calcular_dimensoes_pacote(items)
        
        # Valor declarado (soma dos preços dos produtos)
        valor_declarado = sum(
            float(item.get('unit_price', 0)) * item.get('quantity', 1) 
            for item in items
        )
        
        opcoes_frete = []
        
        # Calcular para cada serviço
        for nome_servico, codigo_servico in SERVICOS_CORREIOS.items():
            try:
                params = {
                    'nCdEmpresa': '',
                    'sDsSenha': '',
                    'nCdServico': codigo_servico,
                    'sCepOrigem': CORREIOS_CEP_ORIGEM,
                    'sCepDestino': cep_destino,
                    'nVlPeso': peso,
                    'nCdFormato': '1',  # Caixa/pacote
                    'nVlComprimento': comprimento,
                    'nVlAltura': altura,
                    'nVlLargura': largura,
                    'nVlDiametro': '0',
                    'sCdMaoPropria': 'N',
                    'nVlValorDeclarado': valor_declarado,
                    'sCdAvisoRecebimento': 'N'
                }
                
                response = requests.get(CORREIOS_BASE_URL, params=params, timeout=10)
                
                if response.status_code == 200:
                    # Parse XML response
                    root = ET.fromstring(response.content)
                    servico = root.find('.//cServico')
                    
                    if servico is not None:
                        erro = servico.find('Erro').text if servico.find('Erro') is not None else '0'
                        
                        if erro == '0':
                            valor = servico.find('Valor').text.replace(',', '.')
                            prazo = servico.find('PrazoEntrega').text
                            
                            opcoes_frete.append({
                                'service': nome_servico,
                                'service_code': codigo_servico,
                                'price': float(valor),
                                'delivery_days': int(prazo),
                                'description': f'{nome_servico} - {prazo} dia(s) úteis'
                            })
                        else:
                            msg_erro = servico.find('MsgErro').text if servico.find('MsgErro') is not None else 'Erro desconhecido'
                            print(f"Erro no serviço {nome_servico}: {msg_erro}")
            
            except Exception as e:
                print(f"Erro ao calcular {nome_servico}: {str(e)}")
                continue
        
        # Se não conseguiu calcular nenhum serviço, retornar valores padrão
        if not opcoes_frete:
            opcoes_frete = [
                {
                    'service': 'PAC',
                    'service_code': '04510',
                    'price': 15.90,
                    'delivery_days': 8,
                    'description': 'PAC - 8 dia(s) úteis (estimativa)'
                },
                {
                    'service': 'SEDEX',
                    'service_code': '04014',
                    'price': 25.90,
                    'delivery_days': 3,
                    'description': 'SEDEX - 3 dia(s) úteis (estimativa)'
                }
            ]
        
        # Ordenar por preço
        opcoes_frete.sort(key=lambda x: x['price'])
        
        return jsonify({
            'success': True,
            'shipping_options': opcoes_frete,
            'origin_cep': CORREIOS_CEP_ORIGEM,
            'destination_cep': cep_destino,
            'package_info': {
                'weight_kg': peso,
                'dimensions_cm': {
                    'length': comprimento,
                    'width': largura,
                    'height': altura
                },
                'declared_value': valor_declarado
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao calcular frete: {str(e)}'
        }), 500

@shipping_bp.route('/shipping/track/<tracking_code>', methods=['GET'])
def track_package(tracking_code):
    """Rastrear encomenda pelos Correios"""
    try:
        # URL da API de rastreamento dos Correios
        url = f"https://api.correios.com.br/sro/v1/objetos/{tracking_code}"
        
        # Headers necessários (seria necessário token real em produção)
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        
        # Em produção, seria necessário autenticação
        # Por enquanto, retornar dados simulados
        tracking_data = {
            'tracking_code': tracking_code,
            'status': 'Em trânsito',
            'last_update': '2025-07-15T10:30:00',
            'events': [
                {
                    'date': '2025-07-15T10:30:00',
                    'description': 'Objeto em trânsito - por favor aguarde',
                    'location': 'Centro de Distribuição - São Paulo/SP'
                },
                {
                    'date': '2025-07-14T16:45:00',
                    'description': 'Objeto postado após o horário limite da unidade',
                    'location': 'Agência dos Correios - Monte Belo/MG'
                },
                {
                    'date': '2025-07-14T14:20:00',
                    'description': 'Objeto postado',
                    'location': 'Agência dos Correios - Monte Belo/MG'
                }
            ]
        }
        
        return jsonify({
            'success': True,
            'tracking': tracking_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao rastrear encomenda: {str(e)}'
        }), 500

@shipping_bp.route('/shipping/cep/<cep>', methods=['GET'])
def get_address_by_cep(cep):
    """Buscar endereço pelo CEP usando ViaCEP"""
    try:
        cep_clean = cep.replace('-', '').replace('.', '')
        
        if len(cep_clean) != 8:
            return jsonify({
                'success': False,
                'error': 'CEP inválido'
            }), 400
        
        # Usar API ViaCEP
        url = f"https://viacep.com.br/ws/{cep_clean}/json/"
        response = requests.get(url, timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            
            if 'erro' in data:
                return jsonify({
                    'success': False,
                    'error': 'CEP não encontrado'
                }), 404
            
            return jsonify({
                'success': True,
                'address': {
                    'cep': data.get('cep'),
                    'street': data.get('logradouro'),
                    'neighborhood': data.get('bairro'),
                    'city': data.get('localidade'),
                    'state': data.get('uf'),
                    'state_name': data.get('estado'),
                    'region': data.get('regiao')
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Erro ao consultar CEP'
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao buscar endereço: {str(e)}'
        }), 500

