import { useState } from 'react'
import { Heart, ShoppingCart, Filter, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

const ProductGrid = () => {
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [selectedSize, setSelectedSize] = useState('all')
  const [priceRange, setPriceRange] = useState([0, 1000])
  const [showFilters, setShowFilters] = useState(false)
  const [favorites, setFavorites] = useState(new Set())

  const categories = [
    { id: 'all', name: 'Todos' },
    { id: 'tees', name: 'Camisetas' },
    { id: 'hoodies', name: 'Moletons' },
    { id: 'jackets', name: 'Jaquetas' },
    { id: 'pants', name: 'Calças' },
    { id: 'accessories', name: 'Acessórios' }
  ]

  const sizes = ['P', 'M', 'G', 'GG', 'XG']

  const products = [
    {
      id: 1,
      name: 'TEE PACKS LOGO BLACK',
      price: 189.90,
      originalPrice: null,
      category: 'tees',
      sizes: ['P', 'M', 'G', 'GG'],
      colors: ['black', 'white'],
      image: '/api/placeholder/300/400',
      isNew: true,
      isOnSale: false,
      inStock: true
    },
    {
      id: 2,
      name: 'HOODIE PACKS URBAN WHITE',
      price: 299.90,
      originalPrice: 399.90,
      category: 'hoodies',
      sizes: ['M', 'G', 'GG', 'XG'],
      colors: ['white', 'gray'],
      image: '/api/placeholder/300/400',
      isNew: false,
      isOnSale: true,
      inStock: true
    },
    {
      id: 3,
      name: 'JACKET PACKS STREET DENIM',
      price: 449.90,
      originalPrice: null,
      category: 'jackets',
      sizes: ['P', 'M', 'G'],
      colors: ['blue', 'black'],
      image: '/api/placeholder/300/400',
      isNew: true,
      isOnSale: false,
      inStock: false
    },
    {
      id: 4,
      name: 'PANTS PACKS CARGO BLACK',
      price: 259.90,
      originalPrice: null,
      category: 'pants',
      sizes: ['M', 'G', 'GG'],
      colors: ['black', 'olive'],
      image: '/api/placeholder/300/400',
      isNew: false,
      isOnSale: false,
      inStock: true
    },
    {
      id: 5,
      name: 'CAP PACKS LOGO NEON',
      price: 89.90,
      originalPrice: 119.90,
      category: 'accessories',
      sizes: ['Único'],
      colors: ['black', 'neon'],
      image: '/api/placeholder/300/400',
      isNew: false,
      isOnSale: true,
      inStock: true
    },
    {
      id: 6,
      name: 'TEE PACKS GRAPHIC WHITE',
      price: 199.90,
      originalPrice: null,
      category: 'tees',
      sizes: ['P', 'M', 'G', 'GG', 'XG'],
      colors: ['white', 'black'],
      image: '/api/placeholder/300/400',
      isNew: true,
      isOnSale: false,
      inStock: true
    }
  ]

  const filteredProducts = products.filter(product => {
    const categoryMatch = selectedCategory === 'all' || product.category === selectedCategory
    const sizeMatch = selectedSize === 'all' || product.sizes.includes(selectedSize)
    const priceMatch = product.price >= priceRange[0] && product.price <= priceRange[1]
    
    return categoryMatch && sizeMatch && priceMatch
  })

  const toggleFavorite = (productId) => {
    const newFavorites = new Set(favorites)
    if (newFavorites.has(productId)) {
      newFavorites.delete(productId)
    } else {
      newFavorites.add(productId)
    }
    setFavorites(newFavorites)
  }

  const ProductCard = ({ product }) => (
    <div className="product-card rounded-lg overflow-hidden group hover-scale">
      {/* Image Container */}
      <div className="relative aspect-[3/4] overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.isNew && (
            <span className="bg-primary text-primary-foreground px-2 py-1 text-xs font-semibold rounded">
              NOVO
            </span>
          )}
          {product.isOnSale && (
            <span className="bg-accent text-accent-foreground px-2 py-1 text-xs font-semibold rounded">
              OFERTA
            </span>
          )}
          {!product.inStock && (
            <span className="bg-destructive text-white px-2 py-1 text-xs font-semibold rounded">
              ESGOTADO
            </span>
          )}
        </div>

        {/* Actions */}
        <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button
            size="sm"
            variant="secondary"
            className="w-10 h-10 p-0 rounded-full"
            onClick={() => toggleFavorite(product.id)}
          >
            <Heart 
              className={`h-4 w-4 ${favorites.has(product.id) ? 'fill-red-500 text-red-500' : ''}`} 
            />
          </Button>
        </div>

        {/* Quick Add to Cart */}
        <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button 
            className="w-full btn-primary"
            disabled={!product.inStock}
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            {product.inStock ? 'Adicionar ao Carrinho' : 'Indisponível'}
          </Button>
        </div>
      </div>

      {/* Product Info */}
      <div className="p-4">
        <h3 className="font-semibold text-white mb-2 line-clamp-2">
          {product.name}
        </h3>
        
        <div className="flex items-center gap-2 mb-3">
          {product.originalPrice && (
            <span className="text-sm text-gray-400 line-through">
              R$ {product.originalPrice.toFixed(2)}
            </span>
          )}
          <span className="text-lg font-bold neon-green">
            R$ {product.price.toFixed(2)}
          </span>
        </div>

        {/* Sizes */}
        <div className="flex flex-wrap gap-1 mb-3">
          {product.sizes.map(size => (
            <span 
              key={size}
              className="text-xs px-2 py-1 border border-white/20 rounded text-gray-300"
            >
              {size}
            </span>
          ))}
        </div>

        {/* Colors */}
        <div className="flex gap-2">
          {product.colors.map(color => (
            <div
              key={color}
              className={`w-4 h-4 rounded-full border border-white/30 ${
                color === 'black' ? 'bg-black' :
                color === 'white' ? 'bg-white' :
                color === 'gray' ? 'bg-gray-500' :
                color === 'blue' ? 'bg-blue-600' :
                color === 'olive' ? 'bg-green-700' :
                color === 'neon' ? 'bg-primary' : 'bg-gray-400'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  )

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">Produtos</h2>
            <p className="text-gray-400">
              {filteredProducts.length} produtos encontrados
            </p>
          </div>
          
          {/* Mobile Filter Button */}
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="md:hidden"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filtros
          </Button>
        </div>

        <div className="flex gap-8">
          {/* Filters Sidebar */}
          <div className={`${showFilters ? 'block' : 'hidden'} md:block w-full md:w-64 space-y-6`}>
            {/* Categories */}
            <div>
              <h3 className="font-semibold text-white mb-4">Categorias</h3>
              <div className="space-y-2">
                {categories.map(category => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`block w-full text-left px-3 py-2 rounded transition-colors ${
                      selectedCategory === category.id
                        ? 'bg-primary text-primary-foreground'
                        : 'text-gray-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    {category.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Sizes */}
            <div>
              <h3 className="font-semibold text-white mb-4">Tamanhos</h3>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSelectedSize('all')}
                  className={`px-3 py-2 rounded border transition-colors ${
                    selectedSize === 'all'
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-white/20 text-gray-300 hover:border-white/40'
                  }`}
                >
                  Todos
                </button>
                {sizes.map(size => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`px-3 py-2 rounded border transition-colors ${
                      selectedSize === size
                        ? 'border-primary bg-primary text-primary-foreground'
                        : 'border-white/20 text-gray-300 hover:border-white/40'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div>
              <h3 className="font-semibold text-white mb-4">Faixa de Preço</h3>
              <div className="space-y-3">
                <input
                  type="range"
                  min="0"
                  max="1000"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([0, parseInt(e.target.value)])}
                  className="w-full accent-primary"
                />
                <div className="flex justify-between text-sm text-gray-400">
                  <span>R$ 0</span>
                  <span>R$ {priceRange[1]}</span>
                </div>
              </div>
            </div>

            {/* Clear Filters */}
            <Button
              variant="outline"
              onClick={() => {
                setSelectedCategory('all')
                setSelectedSize('all')
                setPriceRange([0, 1000])
              }}
              className="w-full"
            >
              Limpar Filtros
            </Button>
          </div>

          {/* Products Grid */}
          <div className="flex-1">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-16">
                <p className="text-gray-400 text-lg">
                  Nenhum produto encontrado com os filtros selecionados.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

export default ProductGrid

