from flask import Blueprint, request, jsonify, session
from functools import wraps
from sqlalchemy import desc, asc, func
from datetime import datetime, timedelta
from src.models.user import db, User
from src.models.product import Product, Category, ProductImage, ProductVariant
from src.models.order import Order, OrderItem, OrderStatus, PaymentStatus

admin_bp = Blueprint('admin', __name__)

# Middleware de autenticação para admin
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Em produção, implementar autenticação real
        # Por enquanto, simular usuário admin logado
        if not session.get('admin_logged_in'):
            return jsonify({
                'success': False,
                'error': 'Acesso negado. Login de administrador necessário.'
            }), 401
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/admin/login', methods=['POST'])
def admin_login():
    """Login do administrador"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Dados não fornecidos'
            }), 400
        
        username = data.get('username')
        password = data.get('password')
        
        # Credenciais padrão (em produção, usar hash de senha)
        if username == 'admin' and password == 'packs2025':
            session['admin_logged_in'] = True
            session['admin_user'] = username
            
            return jsonify({
                'success': True,
                'message': 'Login realizado com sucesso',
                'user': {
                    'username': username,
                    'role': 'admin'
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Credenciais inválidas'
            }), 401
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro no login: {str(e)}'
        }), 500

@admin_bp.route('/admin/logout', methods=['POST'])
def admin_logout():
    """Logout do administrador"""
    session.pop('admin_logged_in', None)
    session.pop('admin_user', None)
    
    return jsonify({
        'success': True,
        'message': 'Logout realizado com sucesso'
    })

@admin_bp.route('/admin/dashboard', methods=['GET'])
@admin_required
def get_dashboard_stats():
    """Obter estatísticas do dashboard"""
    try:
        # Estatísticas gerais
        total_products = Product.query.filter_by(is_active=True).count()
        total_orders = Order.query.count()
        total_customers = User.query.count()
        
        # Vendas do mês atual
        current_month = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        monthly_sales = db.session.query(func.sum(Order.total_amount)).filter(
            Order.created_at >= current_month,
            Order.payment_status == PaymentStatus.APPROVED
        ).scalar() or 0
        
        # Pedidos pendentes
        pending_orders = Order.query.filter_by(status=OrderStatus.PENDING).count()
        
        # Produtos com estoque baixo
        low_stock_products = Product.query.filter(
            Product.stock_quantity <= Product.min_stock,
            Product.is_active == True
        ).count()
        
        # Pedidos recentes
        recent_orders = Order.query.order_by(desc(Order.created_at)).limit(5).all()
        
        # Produtos mais vendidos (últimos 30 dias)
        thirty_days_ago = datetime.now() - timedelta(days=30)
        top_products = db.session.query(
            Product.name,
            func.sum(OrderItem.quantity).label('total_sold')
        ).join(OrderItem).join(Order).filter(
            Order.created_at >= thirty_days_ago,
            Order.payment_status == PaymentStatus.APPROVED
        ).group_by(Product.id).order_by(desc('total_sold')).limit(5).all()
        
        return jsonify({
            'success': True,
            'stats': {
                'total_products': total_products,
                'total_orders': total_orders,
                'total_customers': total_customers,
                'monthly_sales': float(monthly_sales),
                'pending_orders': pending_orders,
                'low_stock_products': low_stock_products
            },
            'recent_orders': [order.to_dict() for order in recent_orders],
            'top_products': [
                {'name': name, 'total_sold': int(total_sold)}
                for name, total_sold in top_products
            ]
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao obter estatísticas: {str(e)}'
        }), 500

@admin_bp.route('/admin/products', methods=['GET'])
@admin_required
def get_admin_products():
    """Listar produtos para administração"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        search = request.args.get('search', '')
        category_id = request.args.get('category_id', type=int)
        status = request.args.get('status')  # active, inactive, all
        
        query = Product.query
        
        # Filtros
        if search:
            search_term = f"%{search}%"
            query = query.filter(Product.name.ilike(search_term))
        
        if category_id:
            query = query.filter_by(category_id=category_id)
        
        if status == 'active':
            query = query.filter_by(is_active=True)
        elif status == 'inactive':
            query = query.filter_by(is_active=False)
        
        # Ordenação
        query = query.order_by(desc(Product.created_at))
        
        # Paginação
        pagination = query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        products = [product.to_dict() for product in pagination.items]
        
        return jsonify({
            'success': True,
            'products': products,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao listar produtos: {str(e)}'
        }), 500

@admin_bp.route('/admin/products', methods=['POST'])
@admin_required
def create_product():
    """Criar novo produto"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Dados não fornecidos'
            }), 400
        
        # Validar campos obrigatórios
        required_fields = ['name', 'price', 'category_id']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'error': f'Campo obrigatório: {field}'
                }), 400
        
        # Gerar slug
        slug = data['name'].lower().replace(' ', '-').replace('/', '-')
        
        # Verificar se slug já existe
        existing_product = Product.query.filter_by(slug=slug).first()
        if existing_product:
            slug = f"{slug}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # Criar produto
        product = Product(
            name=data['name'],
            slug=slug,
            description=data.get('description', ''),
            short_description=data.get('short_description', ''),
            price=data['price'],
            original_price=data.get('original_price'),
            category_id=data['category_id'],
            stock_quantity=data.get('stock_quantity', 0),
            min_stock=data.get('min_stock', 5),
            is_active=data.get('is_active', True),
            is_featured=data.get('is_featured', False),
            is_new=data.get('is_new', False),
            is_on_sale=data.get('is_on_sale', False),
            meta_title=data.get('meta_title'),
            meta_description=data.get('meta_description')
        )
        
        db.session.add(product)
        db.session.flush()
        
        # Adicionar imagens se fornecidas
        if data.get('images'):
            for i, image_data in enumerate(data['images']):
                image = ProductImage(
                    product_id=product.id,
                    image_url=image_data['url'],
                    alt_text=image_data.get('alt_text', product.name),
                    is_primary=i == 0,
                    sort_order=i
                )
                db.session.add(image)
        
        # Adicionar variações se fornecidas
        if data.get('variants'):
            for variant_data in data['variants']:
                variant = ProductVariant(
                    product_id=product.id,
                    size=variant_data.get('size'),
                    color=variant_data.get('color'),
                    color_hex=variant_data.get('color_hex'),
                    stock_quantity=variant_data.get('stock_quantity', 0),
                    price_adjustment=variant_data.get('price_adjustment', 0),
                    sku=variant_data.get('sku')
                )
                db.session.add(variant)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Produto criado com sucesso',
            'product': product.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': f'Erro ao criar produto: {str(e)}'
        }), 500

@admin_bp.route('/admin/products/<int:product_id>', methods=['PUT'])
@admin_required
def update_product(product_id):
    """Atualizar produto"""
    try:
        product = Product.query.get(product_id)
        
        if not product:
            return jsonify({
                'success': False,
                'error': 'Produto não encontrado'
            }), 404
        
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Dados não fornecidos'
            }), 400
        
        # Atualizar campos
        for field in ['name', 'description', 'short_description', 'price', 
                     'original_price', 'category_id', 'stock_quantity', 'min_stock',
                     'is_active', 'is_featured', 'is_new', 'is_on_sale',
                     'meta_title', 'meta_description']:
            if field in data:
                setattr(product, field, data[field])
        
        # Atualizar slug se nome mudou
        if 'name' in data:
            new_slug = data['name'].lower().replace(' ', '-').replace('/', '-')
            if new_slug != product.slug:
                existing = Product.query.filter_by(slug=new_slug).filter(Product.id != product_id).first()
                if existing:
                    new_slug = f"{new_slug}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
                product.slug = new_slug
        
        product.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Produto atualizado com sucesso',
            'product': product.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': f'Erro ao atualizar produto: {str(e)}'
        }), 500

@admin_bp.route('/admin/products/<int:product_id>', methods=['DELETE'])
@admin_required
def delete_product(product_id):
    """Deletar produto (soft delete)"""
    try:
        product = Product.query.get(product_id)
        
        if not product:
            return jsonify({
                'success': False,
                'error': 'Produto não encontrado'
            }), 404
        
        # Soft delete - apenas desativar
        product.is_active = False
        product.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Produto desativado com sucesso'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': f'Erro ao deletar produto: {str(e)}'
        }), 500

@admin_bp.route('/admin/orders', methods=['GET'])
@admin_required
def get_admin_orders():
    """Listar pedidos para administração"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        payment_status = request.args.get('payment_status')
        search = request.args.get('search', '')
        
        query = Order.query
        
        # Filtros
        if status:
            query = query.filter_by(status=OrderStatus(status))
        
        if payment_status:
            query = query.filter_by(payment_status=PaymentStatus(payment_status))
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                db.or_(
                    Order.order_number.ilike(search_term),
                    Order.customer_name.ilike(search_term),
                    Order.customer_email.ilike(search_term)
                )
            )
        
        # Ordenação
        query = query.order_by(desc(Order.created_at))
        
        # Paginação
        pagination = query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        orders = [order.to_dict() for order in pagination.items]
        
        return jsonify({
            'success': True,
            'orders': orders,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao listar pedidos: {str(e)}'
        }), 500

@admin_bp.route('/admin/orders/<int:order_id>/status', methods=['PUT'])
@admin_required
def update_order_status(order_id):
    """Atualizar status do pedido"""
    try:
        order = Order.query.get(order_id)
        
        if not order:
            return jsonify({
                'success': False,
                'error': 'Pedido não encontrado'
            }), 404
        
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Dados não fornecidos'
            }), 400
        
        new_status = data.get('status')
        tracking_code = data.get('tracking_code')
        admin_notes = data.get('admin_notes')
        
        if new_status:
            order.status = OrderStatus(new_status)
        
        if tracking_code:
            order.tracking_code = tracking_code
        
        if admin_notes:
            order.admin_notes = admin_notes
        
        order.updated_at = datetime.utcnow()
        
        # Se status for "shipped", definir data de envio
        if new_status == 'shipped' and not order.delivered_at:
            order.estimated_delivery = datetime.utcnow() + timedelta(days=7)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Status do pedido atualizado com sucesso',
            'order': order.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': f'Erro ao atualizar status: {str(e)}'
        }), 500

