import { useState, useEffect } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

const HeroBanner = () => {
  const [currentSlide, setCurrentSlide] = useState(0)

  const slides = [
    {
      id: 1,
      title: "Nova Coleção",
      subtitle: "STREETWEAR AUTÊNTICO",
      description: "Descubra as últimas tendências do streetwear urbano",
      cta: "Explorar Agora",
      background: "linear-gradient(135deg, #000000 0%, #1a1a1a 50%, #000000 100%)",
      textColor: "text-white",
      accent: "neon-green"
    },
    {
      id: 2,
      title: "Lançamento Exclusivo",
      subtitle: "EDIÇÃO LIMITADA",
      description: "Peças únicas para quem busca originalidade",
      cta: "Ver Coleção",
      background: "linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 50%, #1a1a1a 100%)",
      textColor: "text-white",
      accent: "neon-orange"
    },
    {
      id: 3,
      title: "Ofertas Especiais",
      subtitle: "ATÉ 50% OFF",
      description: "Aproveite os melhores preços em peças selecionadas",
      cta: "Aproveitar",
      background: "linear-gradient(135deg, #000000 0%, #1a1a1a 30%, #2a2a2a 70%, #000000 100%)",
      textColor: "text-white",
      accent: "neon-purple"
    }
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)

    return () => clearInterval(timer)
  }, [slides.length])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  const goToSlide = (index) => {
    setCurrentSlide(index)
  }

  return (
    <section className="relative h-screen overflow-hidden">
      {/* Slides */}
      <div className="relative h-full">
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
            style={{ background: slide.background }}
          >
            {/* Content */}
            <div className="container mx-auto px-4 h-full flex items-center">
              <div className="max-w-2xl animate-fade-in-up">
                <h2 className={`text-sm font-semibold tracking-wider uppercase mb-4 ${slide.accent}`}>
                  {slide.subtitle}
                </h2>
                <h1 className={`text-6xl md:text-8xl font-black mb-6 ${slide.textColor} font-space-grotesk leading-none`}>
                  {slide.title}
                </h1>
                <p className={`text-xl mb-8 ${slide.textColor} opacity-80 max-w-lg`}>
                  {slide.description}
                </p>
                <Button 
                  size="lg" 
                  className="btn-primary text-lg px-8 py-4 hover-scale"
                >
                  {slide.cta}
                </Button>
              </div>
            </div>

            {/* Decorative Elements */}
            <div className="absolute top-1/4 right-10 w-32 h-32 border border-white/20 rotate-45 hidden lg:block"></div>
            <div className="absolute bottom-1/4 right-20 w-16 h-16 border border-white/10 rotate-12 hidden lg:block"></div>
          </div>
        ))}
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white hover:text-primary transition-colors duration-300 z-10"
      >
        <ChevronLeft className="h-12 w-12" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white hover:text-primary transition-colors duration-300 z-10"
      >
        <ChevronRight className="h-12 w-12" />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-3 z-10">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide 
                ? 'bg-primary scale-125' 
                : 'bg-white/50 hover:bg-white/80'
            }`}
          />
        ))}
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 right-8 text-white/60 hidden md:block">
        <div className="flex flex-col items-center space-y-2">
          <span className="text-sm font-medium tracking-wider rotate-90 origin-center">SCROLL</span>
          <div className="w-px h-12 bg-white/30"></div>
        </div>
      </div>
    </section>
  )
}

export default HeroBanner

