import { Instagram, Facebook, Twitter, Youtube, Mail, MapPin, Phone } from 'lucide-react'
import { Button } from '@/components/ui/button'

const Footer = () => {
  const currentYear = new Date().getFullYear()

  const footerLinks = {
    company: [
      { name: 'Sobre Nós', href: '#sobre' },
      { name: 'Nossa História', href: '#historia' },
      { name: 'Trabalhe Conosco', href: '#carreiras' },
      { name: 'Imprensa', href: '#imprensa' }
    ],
    support: [
      { name: 'Contato', href: '#contato' },
      { name: 'Trocas & Devoluções', href: '#trocas' },
      { name: 'Envio & Pagamento', href: '#envio' },
      { name: 'FAQ', href: '#faq' }
    ],
    legal: [
      { name: 'Política de Privacidade', href: '#privacidade' },
      { name: 'Termos de Uso', href: '#termos' },
      { name: 'Política de Cookies', href: '#cookies' },
      { name: 'LGPD', href: '#lgpd' }
    ]
  }

  const socialLinks = [
    { name: 'Instagram', icon: Instagram, href: 'https://instagram.com/packsorg', color: 'hover:text-pink-400' },
    { name: 'Facebook', icon: Facebook, href: '#', color: 'hover:text-blue-400' },
    { name: 'Twitter', icon: Twitter, href: '#', color: 'hover:text-blue-300' },
    { name: 'YouTube', icon: Youtube, href: '#', color: 'hover:text-red-400' }
  ]

  return (
    <footer className="bg-black border-t border-white/10">
      {/* Newsletter Section */}
      <div className="border-b border-white/10">
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-2xl mx-auto text-center">
            <h3 className="text-2xl font-bold text-white mb-4">
              Fique por dentro das novidades
            </h3>
            <p className="text-gray-400 mb-6">
              Receba em primeira mão nossos lançamentos, ofertas exclusivas e conteúdo especial
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Seu melhor e-mail"
                className="flex-1 bg-card border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-primary transition-colors"
              />
              <Button className="btn-primary px-6 py-3">
                <Mail className="h-4 w-4 mr-2" />
                Inscrever
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-3">
              Ao se inscrever, você concorda com nossa Política de Privacidade
            </p>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <h2 className="logo-packs text-white text-3xl mb-4">packs</h2>
            <p className="text-gray-400 mb-6 leading-relaxed">
              Streetwear autêntico para quem vive a cultura urbana. 
              Qualidade premium, design exclusivo e atitude em cada peça.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center text-gray-400">
                <MapPin className="h-4 w-4 mr-3 text-primary" />
                <span className="text-sm">Monte Belo, MG - Brasil</span>
              </div>
              <div className="flex items-center text-gray-400">
                <Mail className="h-4 w-4 mr-3 text-primary" />
                <span className="text-sm">packsorganization@gmail.com</span>
              </div>
              <div className="flex items-center text-gray-400">
                <Phone className="h-4 w-4 mr-3 text-primary" />
                <span className="text-sm">+55 (35) 9999-9999</span>
              </div>
            </div>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="font-semibold text-white mb-4">Empresa</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-primary transition-colors duration-300 text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h4 className="font-semibold text-white mb-4">Suporte</h4>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-primary transition-colors duration-300 text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h4 className="font-semibold text-white mb-4">Legal</h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-primary transition-colors duration-300 text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Copyright */}
            <div className="text-gray-400 text-sm">
              © {currentYear} packs. Todos os direitos reservados.
            </div>

            {/* Social Links */}
            <div className="flex items-center space-x-4">
              <span className="text-gray-400 text-sm mr-2">Siga-nos:</span>
              {socialLinks.map((social) => {
                const IconComponent = social.icon
                return (
                  <a
                    key={social.name}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`text-gray-400 transition-colors duration-300 ${social.color}`}
                    aria-label={social.name}
                  >
                    <IconComponent className="h-5 w-5" />
                  </a>
                )
              })}
            </div>

            {/* Payment Methods */}
            <div className="flex items-center space-x-2">
              <span className="text-gray-400 text-sm">Pagamento:</span>
              <div className="flex space-x-2">
                <div className="w-8 h-5 bg-gradient-to-r from-blue-600 to-blue-400 rounded text-white text-xs flex items-center justify-center font-bold">
                  VISA
                </div>
                <div className="w-8 h-5 bg-gradient-to-r from-red-600 to-orange-400 rounded text-white text-xs flex items-center justify-center font-bold">
                  MC
                </div>
                <div className="w-8 h-5 bg-primary rounded text-primary-foreground text-xs flex items-center justify-center font-bold">
                  PIX
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Cookie Notice */}
      <div className="bg-card border-t border-white/10">
        <div className="container mx-auto px-4 py-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm">
            <p className="text-gray-400">
              Utilizamos cookies para melhorar sua experiência. 
              <a href="#cookies" className="text-primary hover:underline ml-1">
                Saiba mais
              </a>
            </p>
            <Button variant="outline" size="sm">
              Aceitar Cookies
            </Button>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

