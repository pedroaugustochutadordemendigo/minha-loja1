# Conceito de Design - Marca PACKS
## E-commerce Streetwear

### 1. Identidade Visual

#### Logomarca
- **Nome**: "packs" (sempre em minúsculas)
- **Estilo**: Tipografia ousada e moderna, inspirada no streetwear urbano
- **Variações**: Versão horizontal para cabeçalho, versão compacta para favicon
- **Aplicação**: Centralizada no cabeçalho, adaptável para diferentes tamanhos

#### Paleta de Cores
**Cores Primárias:**
- **Preto Principal**: #000000 (fundo principal)
- **Branco Contraste**: #FFFFFF (textos e elementos)
- **Cinza Escuro**: #1A1A1A (cards e seções)

**Cores Vibrantes (Acentos):**
- **Verde Neon**: #00FF88 (CTAs principais, destaques)
- **Laranja Vibrante**: #FF6B35 (promoções, ofertas)
- **Roxo Elétrico**: #8B5CF6 (novidades, lançamentos)
- **Azul Ciano**: #00D4FF (links, interações)

#### Tipografia
**Fonte Principal**: Inter (moderna, legível)
- **Títulos**: 32px - 48px, peso 700-900
- **Subtítulos**: 20px - 24px, peso 600
- **Corpo**: 16px - 18px, peso 400-500
- **Botões**: 14px - 16px, peso 600

**Fonte Secundária**: Space Grotesk (para elementos especiais)
- **Logo**: Customizada, peso 700
- **Destaques**: Elementos gráficos especiais

### 2. Layout e Estrutura

#### Header (Cabeçalho)
- **Fundo**: Preto sólido com transparência em scroll
- **Logo**: Centralizada, branca
- **Menu**: Horizontal, minimalista
  - Home | Produtos | Novidades | Coleções | Ofertas
- **Ícones**: Conta, Favoritos, Carrinho (com contador)
- **Busca**: Barra expansível com ícone de lupa

#### Navegação Principal
```
[LOGO PACKS]
Home  Produtos  Novidades  Coleções  Ofertas    [🔍] [👤] [❤️] [🛒]
```

#### Banner Principal
- **Estilo**: Full-width, imagens impactantes
- **Rotativo**: 3-5 slides com transições suaves
- **Conteúdo**: Lançamentos, campanhas, editoriais
- **CTA**: Botões com cores vibrantes

### 3. Grid de Produtos

#### Layout
- **Desktop**: 4 colunas
- **Tablet**: 3 colunas  
- **Mobile**: 2 colunas

#### Cards de Produto
- **Fundo**: Cinza escuro (#1A1A1A)
- **Imagem**: Hover com zoom sutil
- **Informações**:
  - Nome do produto (branco)
  - Preço (verde neon para destaque)
  - Selo de status (novo/oferta/esgotado)

#### Filtros
- **Posição**: Sidebar esquerda (desktop) / Modal (mobile)
- **Categorias**: Checkboxes com cores vibrantes
- **Preço**: Slider com gradiente
- **Tamanhos**: Botões circulares

### 4. Página do Produto

#### Galeria de Imagens
- **Principal**: Imagem grande com zoom
- **Thumbnails**: Carrossel horizontal
- **Recursos**: Zoom, 360º, vídeos

#### Informações
- **Nome**: Tipografia grande, peso 700
- **Preço**: Verde neon, destaque
- **Variações**: Seletores visuais (cores/tamanhos)
- **Descrição**: Texto limpo, bem espaçado
- **Tabela de Medidas**: Modal expansível

#### CTAs
- **Adicionar ao Carrinho**: Botão principal (verde neon)
- **Favoritar**: Ícone de coração
- **Compartilhar**: Instagram, WhatsApp

### 5. Elementos Interativos

#### Botões
- **Primário**: Fundo verde neon, texto preto
- **Secundário**: Borda branca, texto branco
- **Hover**: Transições suaves (0.3s)

#### Animações
- **Hover**: Escala sutil (1.05x)
- **Loading**: Spinners com cores vibrantes
- **Transições**: Fade, slide suaves

#### Micro-interações
- **Carrinho**: Animação de adição
- **Favoritos**: Pulso no coração
- **Notificações**: Toast messages

### 6. Responsividade

#### Breakpoints
- **Desktop**: 1200px+
- **Tablet**: 768px - 1199px
- **Mobile**: 320px - 767px

#### Adaptações Mobile
- **Menu**: Hamburger com overlay
- **Produtos**: Grid 2 colunas
- **Filtros**: Modal full-screen
- **Carrinho**: Drawer lateral

### 7. Elementos Especiais

#### Instagram Feed
- **Posição**: Seção dedicada na home
- **Layout**: Grid 3x2 ou carrossel
- **Integração**: API oficial @packsorg

#### Newsletter
- **Estilo**: Pop-up minimalista
- **Cores**: Fundo escuro, CTA vibrante
- **Timing**: Após 30s ou intent to exit

#### Footer
- **Fundo**: Preto total
- **Links**: Organizados em colunas
- **Redes Sociais**: Ícones com hover colorido
- **Informações**: Contato, políticas, etc.

### 8. Acessibilidade

#### Contraste
- **Ratio**: Mínimo 4.5:1 para textos
- **Cores**: Sempre testadas para daltonismo

#### Navegação
- **Teclado**: Tab order lógico
- **Screen readers**: Alt texts, ARIA labels
- **Focus**: Indicadores visuais claros

### 9. Performance

#### Otimizações
- **Imagens**: WebP, lazy loading
- **Fonts**: Preload das principais
- **CSS**: Critical path inline
- **JS**: Code splitting, async loading

#### Métricas Alvo
- **LCP**: < 2.5s
- **FID**: < 100ms
- **CLS**: < 0.1

### 10. Mood Board

O design deve transmitir:
- **Modernidade**: Linhas limpas, espaçamento generoso
- **Energia**: Cores vibrantes, animações dinâmicas
- **Autenticidade**: Tipografia ousada, imagens reais
- **Exclusividade**: Elementos premium, atenção aos detalhes

### Referências Visuais
- Sufgang (estrutura e navegação)
- Marcas streetwear premium
- E-commerces modernos com foco em UX
- Interfaces dark mode bem executadas

