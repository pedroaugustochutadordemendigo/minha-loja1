from flask import Blueprint, request, jsonify, current_app
import requests
import json
from datetime import datetime, timedelta
from src.models.user import db
from src.models.order import Order, OrderItem, OrderStatus, PaymentStatus, PaymentMethod

payments_bp = Blueprint('payments', __name__)

# Configurações do Mercado Pago (em produção, usar variáveis de ambiente)
MERCADO_PAGO_ACCESS_TOKEN = "TEST-YOUR-ACCESS-TOKEN"  # Substituir por token real
MERCADO_PAGO_BASE_URL = "https://api.mercadopago.com"

def create_mercado_pago_preference(order_data):
    """Criar preferência de pagamento no Mercado Pago"""
    try:
        url = f"{MERCADO_PAGO_BASE_URL}/checkout/preferences"
        
        headers = {
            "Authorization": f"Bearer {MERCADO_PAGO_ACCESS_TOKEN}",
            "Content-Type": "application/json"
        }
        
        # Itens do pedido
        items = []
        for item in order_data['items']:
            items.append({
                "id": str(item['product_id']),
                "title": item['product_name'],
                "quantity": item['quantity'],
                "unit_price": float(item['unit_price']),
                "currency_id": "BRL"
            })
        
        # Dados da preferência
        preference_data = {
            "items": items,
            "payer": {
                "name": order_data['customer_name'],
                "email": order_data['customer_email'],
                "phone": {
                    "number": order_data.get('customer_phone', '')
                },
                "identification": {
                    "type": "CPF",
                    "number": order_data.get('customer_document', '')
                },
                "address": {
                    "street_name": order_data['shipping_address_line1'],
                    "street_number": "",
                    "zip_code": order_data['shipping_zipcode']
                }
            },
            "payment_methods": {
                "excluded_payment_methods": [],
                "excluded_payment_types": [],
                "installments": 12
            },
            "shipments": {
                "cost": float(order_data['shipping_cost']),
                "mode": "not_specified"
            },
            "back_urls": {
                "success": f"{request.host_url}payment/success",
                "failure": f"{request.host_url}payment/failure",
                "pending": f"{request.host_url}payment/pending"
            },
            "auto_return": "approved",
            "external_reference": order_data['order_number'],
            "notification_url": f"{request.host_url}api/payments/webhook",
            "expires": True,
            "expiration_date_from": datetime.now().isoformat(),
            "expiration_date_to": (datetime.now() + timedelta(days=7)).isoformat()
        }
        
        response = requests.post(url, headers=headers, json=preference_data)
        
        if response.status_code == 201:
            return response.json()
        else:
            print(f"Erro ao criar preferência MP: {response.text}")
            return None
            
    except Exception as e:
        print(f"Erro na integração Mercado Pago: {str(e)}")
        return None

@payments_bp.route('/payments/create-preference', methods=['POST'])
def create_payment_preference():
    """Criar preferência de pagamento"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Dados não fornecidos'
            }), 400
        
        # Validar dados obrigatórios
        required_fields = [
            'customer_name', 'customer_email', 'items',
            'shipping_address_line1', 'shipping_city', 
            'shipping_state', 'shipping_zipcode'
        ]
        
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'error': f'Campo obrigatório: {field}'
                }), 400
        
        # Gerar número do pedido
        order_number = f"PK{datetime.now().strftime('%Y%m%d%H%M%S')}"
        data['order_number'] = order_number
        
        # Calcular totais
        subtotal = sum(
            float(item['unit_price']) * item['quantity'] 
            for item in data['items']
        )
        shipping_cost = float(data.get('shipping_cost', 0))
        discount = float(data.get('discount_amount', 0))
        total = subtotal + shipping_cost - discount
        
        data['subtotal'] = subtotal
        data['total_amount'] = total
        
        # Criar preferência no Mercado Pago
        preference = create_mercado_pago_preference(data)
        
        if preference:
            # Salvar pedido no banco (status pendente)
            order = Order(
                order_number=order_number,
                customer_email=data['customer_email'],
                customer_name=data['customer_name'],
                customer_phone=data.get('customer_phone'),
                customer_document=data.get('customer_document'),
                status=OrderStatus.PENDING,
                payment_status=PaymentStatus.PENDING,
                subtotal=subtotal,
                shipping_cost=shipping_cost,
                discount_amount=discount,
                total_amount=total,
                coupon_code=data.get('coupon_code'),
                shipping_address_line1=data['shipping_address_line1'],
                shipping_address_line2=data.get('shipping_address_line2'),
                shipping_city=data['shipping_city'],
                shipping_state=data['shipping_state'],
                shipping_zipcode=data['shipping_zipcode'],
                shipping_method=data.get('shipping_method'),
                payment_id=preference['id'],
                payment_data=preference
            )
            
            db.session.add(order)
            db.session.flush()
            
            # Adicionar itens do pedido
            for item_data in data['items']:
                order_item = OrderItem(
                    order_id=order.id,
                    product_id=item_data['product_id'],
                    variant_id=item_data.get('variant_id'),
                    product_name=item_data['product_name'],
                    product_sku=item_data.get('product_sku'),
                    variant_info=item_data.get('variant_info'),
                    unit_price=item_data['unit_price'],
                    quantity=item_data['quantity'],
                    total_price=float(item_data['unit_price']) * item_data['quantity']
                )
                db.session.add(order_item)
            
            db.session.commit()
            
            return jsonify({
                'success': True,
                'order_id': order.id,
                'order_number': order_number,
                'preference_id': preference['id'],
                'init_point': preference['init_point'],
                'sandbox_init_point': preference.get('sandbox_init_point'),
                'total_amount': total
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Erro ao criar preferência de pagamento'
            }), 500
            
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': f'Erro ao processar pagamento: {str(e)}'
        }), 500

@payments_bp.route('/payments/webhook', methods=['POST'])
def mercado_pago_webhook():
    """Webhook para receber notificações do Mercado Pago"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'status': 'ok'}), 200
        
        # Verificar tipo de notificação
        if data.get('type') == 'payment':
            payment_id = data.get('data', {}).get('id')
            
            if payment_id:
                # Buscar informações do pagamento
                payment_info = get_payment_info(payment_id)
                
                if payment_info:
                    # Atualizar status do pedido
                    update_order_status(payment_info)
        
        return jsonify({'status': 'ok'}), 200
        
    except Exception as e:
        print(f"Erro no webhook: {str(e)}")
        return jsonify({'status': 'error'}), 500

def get_payment_info(payment_id):
    """Buscar informações do pagamento no Mercado Pago"""
    try:
        url = f"{MERCADO_PAGO_BASE_URL}/v1/payments/{payment_id}"
        
        headers = {
            "Authorization": f"Bearer {MERCADO_PAGO_ACCESS_TOKEN}"
        }
        
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Erro ao buscar pagamento: {response.text}")
            return None
            
    except Exception as e:
        print(f"Erro ao buscar informações do pagamento: {str(e)}")
        return None

def update_order_status(payment_info):
    """Atualizar status do pedido baseado no pagamento"""
    try:
        external_reference = payment_info.get('external_reference')
        payment_status = payment_info.get('status')
        
        if not external_reference:
            return
        
        # Buscar pedido
        order = Order.query.filter_by(order_number=external_reference).first()
        
        if not order:
            return
        
        # Mapear status do MP para status interno
        status_mapping = {
            'approved': PaymentStatus.APPROVED,
            'pending': PaymentStatus.PENDING,
            'rejected': PaymentStatus.REJECTED,
            'cancelled': PaymentStatus.CANCELLED,
            'refunded': PaymentStatus.REFUNDED
        }
        
        new_payment_status = status_mapping.get(payment_status, PaymentStatus.PENDING)
        
        # Atualizar pedido
        order.payment_status = new_payment_status
        order.payment_data = payment_info
        
        # Se aprovado, confirmar pedido
        if new_payment_status == PaymentStatus.APPROVED:
            order.status = OrderStatus.CONFIRMED
            
            # Enviar email de confirmação (implementar depois)
            send_order_confirmation_email(order)
        
        db.session.commit()
        
    except Exception as e:
        print(f"Erro ao atualizar status do pedido: {str(e)}")
        db.session.rollback()

def send_order_confirmation_email(order):
    """Enviar email de confirmação do pedido"""
    # TODO: Implementar envio de email
    # Por enquanto, apenas log
    print(f"📧 Email de confirmação enviado para {order.customer_email}")
    print(f"📦 Pedido {order.order_number} confirmado")

@payments_bp.route('/payments/pix/create', methods=['POST'])
def create_pix_payment():
    """Criar pagamento PIX"""
    try:
        data = request.get_json()
        
        # Simular criação de PIX (em produção, usar API real)
        pix_data = {
            'qr_code': 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==',
            'qr_code_text': '00020126580014br.gov.bcb.pix0136123e4567-e12b-12d1-a456-426614174000520400005303986540510.005802BR5913PACKS STORE6009MONTE BELO62070503***6304ABCD',
            'expiration_date': (datetime.now() + timedelta(minutes=30)).isoformat(),
            'amount': float(data.get('amount', 0))
        }
        
        return jsonify({
            'success': True,
            'pix': pix_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao criar PIX: {str(e)}'
        }), 500

@payments_bp.route('/payments/order/<order_number>/status', methods=['GET'])
def get_order_payment_status(order_number):
    """Verificar status do pagamento de um pedido"""
    try:
        order = Order.query.filter_by(order_number=order_number).first()
        
        if not order:
            return jsonify({
                'success': False,
                'error': 'Pedido não encontrado'
            }), 404
        
        return jsonify({
            'success': True,
            'order': {
                'order_number': order.order_number,
                'status': order.status.value if order.status else None,
                'payment_status': order.payment_status.value if order.payment_status else None,
                'total_amount': float(order.total_amount),
                'created_at': order.created_at.isoformat() if order.created_at else None
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao verificar status: {str(e)}'
        }), 500

