from flask import Blueprint, request, jsonify, session
from src.models.user import db
from src.models.product import Product, ProductVariant
from src.models.order import Cart, CartItem
import uuid

cart_bp = Blueprint('cart', __name__)

def get_or_create_cart():
    """Obter ou criar carrinho para o usuário/sessão"""
    user_id = session.get('user_id')
    session_id = session.get('cart_session_id')
    
    if not session_id:
        session_id = str(uuid.uuid4())
        session['cart_session_id'] = session_id
    
    # Buscar carrinho existente
    if user_id:
        cart = Cart.query.filter_by(user_id=user_id).first()
    else:
        cart = Cart.query.filter_by(session_id=session_id).first()
    
    # Criar novo carrinho se não existir
    if not cart:
        cart = Cart(
            user_id=user_id if user_id else None,
            session_id=session_id if not user_id else None
        )
        db.session.add(cart)
        db.session.commit()
    
    return cart

@cart_bp.route('/cart', methods=['GET'])
def get_cart():
    """Obter carrinho atual"""
    try:
        cart = get_or_create_cart()
        
        return jsonify({
            'success': True,
            'cart': cart.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@cart_bp.route('/cart/add', methods=['POST'])
def add_to_cart():
    """Adicionar item ao carrinho"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Dados não fornecidos'
            }), 400
        
        product_id = data.get('product_id')
        variant_id = data.get('variant_id')
        quantity = data.get('quantity', 1)
        
        if not product_id:
            return jsonify({
                'success': False,
                'error': 'ID do produto é obrigatório'
            }), 400
        
        # Verificar se o produto existe
        product = Product.query.filter_by(id=product_id, is_active=True).first()
        if not product:
            return jsonify({
                'success': False,
                'error': 'Produto não encontrado'
            }), 404
        
        # Verificar variação se fornecida
        variant = None
        if variant_id:
            variant = ProductVariant.query.filter_by(
                id=variant_id, 
                product_id=product_id,
                is_active=True
            ).first()
            if not variant:
                return jsonify({
                    'success': False,
                    'error': 'Variação do produto não encontrada'
                }), 404
        
        # Verificar estoque
        available_stock = variant.stock_quantity if variant else product.stock_quantity
        if available_stock < quantity:
            return jsonify({
                'success': False,
                'error': f'Estoque insuficiente. Disponível: {available_stock}'
            }), 400
        
        # Obter carrinho
        cart = get_or_create_cart()
        
        # Verificar se item já existe no carrinho
        existing_item = CartItem.query.filter_by(
            cart_id=cart.id,
            product_id=product_id,
            variant_id=variant_id
        ).first()
        
        if existing_item:
            # Atualizar quantidade
            new_quantity = existing_item.quantity + quantity
            if available_stock < new_quantity:
                return jsonify({
                    'success': False,
                    'error': f'Estoque insuficiente. Disponível: {available_stock}'
                }), 400
            
            existing_item.quantity = new_quantity
        else:
            # Criar novo item
            unit_price = product.price
            if variant and variant.price_adjustment:
                unit_price += variant.price_adjustment
            
            cart_item = CartItem(
                cart_id=cart.id,
                product_id=product_id,
                variant_id=variant_id,
                quantity=quantity,
                unit_price=unit_price
            )
            db.session.add(cart_item)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Item adicionado ao carrinho',
            'cart': cart.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@cart_bp.route('/cart/update/<int:item_id>', methods=['PUT'])
def update_cart_item(item_id):
    """Atualizar quantidade de item no carrinho"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Dados não fornecidos'
            }), 400
        
        quantity = data.get('quantity')
        
        if quantity is None or quantity < 0:
            return jsonify({
                'success': False,
                'error': 'Quantidade inválida'
            }), 400
        
        # Obter carrinho
        cart = get_or_create_cart()
        
        # Buscar item
        cart_item = CartItem.query.filter_by(
            id=item_id,
            cart_id=cart.id
        ).first()
        
        if not cart_item:
            return jsonify({
                'success': False,
                'error': 'Item não encontrado no carrinho'
            }), 404
        
        if quantity == 0:
            # Remover item
            db.session.delete(cart_item)
        else:
            # Verificar estoque
            available_stock = cart_item.variant.stock_quantity if cart_item.variant else cart_item.product.stock_quantity
            if available_stock < quantity:
                return jsonify({
                    'success': False,
                    'error': f'Estoque insuficiente. Disponível: {available_stock}'
                }), 400
            
            cart_item.quantity = quantity
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Carrinho atualizado',
            'cart': cart.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@cart_bp.route('/cart/remove/<int:item_id>', methods=['DELETE'])
def remove_cart_item(item_id):
    """Remover item do carrinho"""
    try:
        # Obter carrinho
        cart = get_or_create_cart()
        
        # Buscar item
        cart_item = CartItem.query.filter_by(
            id=item_id,
            cart_id=cart.id
        ).first()
        
        if not cart_item:
            return jsonify({
                'success': False,
                'error': 'Item não encontrado no carrinho'
            }), 404
        
        db.session.delete(cart_item)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Item removido do carrinho',
            'cart': cart.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@cart_bp.route('/cart/clear', methods=['DELETE'])
def clear_cart():
    """Limpar carrinho"""
    try:
        cart = get_or_create_cart()
        
        # Remover todos os itens
        CartItem.query.filter_by(cart_id=cart.id).delete()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Carrinho limpo',
            'cart': cart.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@cart_bp.route('/cart/count', methods=['GET'])
def get_cart_count():
    """Obter número de itens no carrinho"""
    try:
        cart = get_or_create_cart()
        
        return jsonify({
            'success': True,
            'count': cart.total_items
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

