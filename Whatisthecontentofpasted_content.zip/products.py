from flask import Blueprint, request, jsonify
from sqlalchemy import or_, and_
from src.models.user import db
from src.models.product import Product, Category, ProductVariant

products_bp = Blueprint('products', __name__)

@products_bp.route('/products', methods=['GET'])
def get_products():
    """Listar produtos com filtros"""
    try:
        # Parâmetros de filtro
        category = request.args.get('category')
        size = request.args.get('size')
        min_price = request.args.get('min_price', type=float)
        max_price = request.args.get('max_price', type=float)
        search = request.args.get('search')
        is_new = request.args.get('is_new', type=bool)
        is_on_sale = request.args.get('is_on_sale', type=bool)
        is_featured = request.args.get('is_featured', type=bool)
        
        # Parâmetros de paginação
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        
        # Parâmetros de ordenação
        sort_by = request.args.get('sort_by', 'created_at')
        sort_order = request.args.get('sort_order', 'desc')
        
        # Query base
        query = Product.query.filter(Product.is_active == True)
        
        # Aplicar filtros
        if category and category != 'all':
            query = query.join(Category).filter(Category.slug == category)
        
        if size and size != 'all':
            query = query.join(ProductVariant).filter(ProductVariant.size == size)
        
        if min_price is not None:
            query = query.filter(Product.price >= min_price)
        
        if max_price is not None:
            query = query.filter(Product.price <= max_price)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                or_(
                    Product.name.ilike(search_term),
                    Product.description.ilike(search_term),
                    Product.short_description.ilike(search_term)
                )
            )
        
        if is_new is not None:
            query = query.filter(Product.is_new == is_new)
        
        if is_on_sale is not None:
            query = query.filter(Product.is_on_sale == is_on_sale)
        
        if is_featured is not None:
            query = query.filter(Product.is_featured == is_featured)
        
        # Aplicar ordenação
        if sort_by == 'price':
            if sort_order == 'asc':
                query = query.order_by(Product.price.asc())
            else:
                query = query.order_by(Product.price.desc())
        elif sort_by == 'name':
            if sort_order == 'asc':
                query = query.order_by(Product.name.asc())
            else:
                query = query.order_by(Product.name.desc())
        else:  # created_at
            if sort_order == 'asc':
                query = query.order_by(Product.created_at.asc())
            else:
                query = query.order_by(Product.created_at.desc())
        
        # Paginação
        pagination = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        products = [product.to_dict() for product in pagination.items]
        
        return jsonify({
            'success': True,
            'products': products,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@products_bp.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    """Obter detalhes de um produto específico"""
    try:
        product = Product.query.filter_by(id=product_id, is_active=True).first()
        
        if not product:
            return jsonify({
                'success': False,
                'error': 'Produto não encontrado'
            }), 404
        
        return jsonify({
            'success': True,
            'product': product.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@products_bp.route('/products/slug/<slug>', methods=['GET'])
def get_product_by_slug(slug):
    """Obter produto pelo slug"""
    try:
        product = Product.query.filter_by(slug=slug, is_active=True).first()
        
        if not product:
            return jsonify({
                'success': False,
                'error': 'Produto não encontrado'
            }), 404
        
        return jsonify({
            'success': True,
            'product': product.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@products_bp.route('/products/featured', methods=['GET'])
def get_featured_products():
    """Obter produtos em destaque"""
    try:
        limit = request.args.get('limit', 8, type=int)
        
        products = Product.query.filter(
            and_(Product.is_active == True, Product.is_featured == True)
        ).order_by(Product.created_at.desc()).limit(limit).all()
        
        return jsonify({
            'success': True,
            'products': [product.to_dict() for product in products]
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@products_bp.route('/products/new', methods=['GET'])
def get_new_products():
    """Obter produtos novos"""
    try:
        limit = request.args.get('limit', 8, type=int)
        
        products = Product.query.filter(
            and_(Product.is_active == True, Product.is_new == True)
        ).order_by(Product.created_at.desc()).limit(limit).all()
        
        return jsonify({
            'success': True,
            'products': [product.to_dict() for product in products]
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@products_bp.route('/products/sale', methods=['GET'])
def get_sale_products():
    """Obter produtos em promoção"""
    try:
        limit = request.args.get('limit', 8, type=int)
        
        products = Product.query.filter(
            and_(Product.is_active == True, Product.is_on_sale == True)
        ).order_by(Product.created_at.desc()).limit(limit).all()
        
        return jsonify({
            'success': True,
            'products': [product.to_dict() for product in products]
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@products_bp.route('/categories', methods=['GET'])
def get_categories():
    """Listar todas as categorias"""
    try:
        categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
        
        return jsonify({
            'success': True,
            'categories': [category.to_dict() for category in categories]
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@products_bp.route('/products/search', methods=['GET'])
def search_products():
    """Buscar produtos"""
    try:
        query_param = request.args.get('q', '').strip()
        
        if not query_param:
            return jsonify({
                'success': False,
                'error': 'Termo de busca é obrigatório'
            }), 400
        
        search_term = f"%{query_param}%"
        
        products = Product.query.filter(
            and_(
                Product.is_active == True,
                or_(
                    Product.name.ilike(search_term),
                    Product.description.ilike(search_term),
                    Product.short_description.ilike(search_term)
                )
            )
        ).order_by(Product.name).limit(20).all()
        
        return jsonify({
            'success': True,
            'products': [product.to_dict() for product in products],
            'query': query_param
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

