#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from src.main import app
from src.models.user import db
from src.models.product import Category, Product, ProductImage, ProductVariant

def seed_database():
    """Popular banco de dados com dados de exemplo"""
    
    with app.app_context():
        # Limpar dados existentes
        db.drop_all()
        db.create_all()
        
        # Criar categorias
        categories = [
            Category(name='Camisetas', slug='tees', description='Camisetas streetwear'),
            Category(name='Moletons', slug='hoodies', description='Moletons e hoodies'),
            Category(name='Jaquetas', slug='jackets', description='Jaquetas e casacos'),
            Category(name='Calças', slug='pants', description='Calças e shorts'),
            Category(name='Acessórios', slug='accessories', description='Bonés, bolsas e acessórios')
        ]
        
        for category in categories:
            db.session.add(category)
        
        db.session.commit()
        
        # Criar produtos
        products_data = [
            {
                'name': 'TEE PACKS LOGO BLACK',
                'slug': 'tee-packs-logo-black',
                'description': 'Camiseta preta com logo da marca PACKS em destaque. Confeccionada em algodão premium com acabamento de alta qualidade.',
                'short_description': 'Camiseta preta com logo PACKS',
                'price': 189.90,
                'category_slug': 'tees',
                'stock_quantity': 50,
                'is_new': True,
                'is_featured': True,
                'variants': [
                    {'size': 'P', 'color': 'Preto', 'color_hex': '#000000', 'stock': 10, 'sku': 'TEE-LOGO-BLK-P'},
                    {'size': 'M', 'color': 'Preto', 'color_hex': '#000000', 'stock': 15, 'sku': 'TEE-LOGO-BLK-M'},
                    {'size': 'G', 'color': 'Preto', 'color_hex': '#000000', 'stock': 15, 'sku': 'TEE-LOGO-BLK-G'},
                    {'size': 'GG', 'color': 'Preto', 'color_hex': '#000000', 'stock': 10, 'sku': 'TEE-LOGO-BLK-GG'},
                ]
            },
            {
                'name': 'HOODIE PACKS URBAN WHITE',
                'slug': 'hoodie-packs-urban-white',
                'description': 'Moletom branco com capuz e design urbano exclusivo. Tecido macio e confortável, perfeito para o dia a dia.',
                'short_description': 'Moletom branco urbano com capuz',
                'price': 299.90,
                'original_price': 399.90,
                'category_slug': 'hoodies',
                'stock_quantity': 30,
                'is_on_sale': True,
                'is_featured': True,
                'variants': [
                    {'size': 'M', 'color': 'Branco', 'color_hex': '#FFFFFF', 'stock': 8, 'sku': 'HOOD-URB-WHT-M'},
                    {'size': 'G', 'color': 'Branco', 'color_hex': '#FFFFFF', 'stock': 12, 'sku': 'HOOD-URB-WHT-G'},
                    {'size': 'GG', 'color': 'Branco', 'color_hex': '#FFFFFF', 'stock': 8, 'sku': 'HOOD-URB-WHT-GG'},
                    {'size': 'XG', 'color': 'Branco', 'color_hex': '#FFFFFF', 'stock': 2, 'sku': 'HOOD-URB-WHT-XG'},
                ]
            },
            {
                'name': 'JACKET PACKS STREET DENIM',
                'slug': 'jacket-packs-street-denim',
                'description': 'Jaqueta jeans com detalhes streetwear únicos. Design moderno e versátil para compor looks urbanos.',
                'short_description': 'Jaqueta jeans streetwear',
                'price': 449.90,
                'category_slug': 'jackets',
                'stock_quantity': 0,  # Esgotado
                'is_new': True,
                'variants': [
                    {'size': 'P', 'color': 'Azul', 'color_hex': '#1E3A8A', 'stock': 0, 'sku': 'JAC-STR-DEN-P'},
                    {'size': 'M', 'color': 'Azul', 'color_hex': '#1E3A8A', 'stock': 0, 'sku': 'JAC-STR-DEN-M'},
                    {'size': 'G', 'color': 'Azul', 'color_hex': '#1E3A8A', 'stock': 0, 'sku': 'JAC-STR-DEN-G'},
                ]
            },
            {
                'name': 'PANTS PACKS CARGO BLACK',
                'slug': 'pants-packs-cargo-black',
                'description': 'Calça cargo preta com múltiplos bolsos e ajuste confortável. Ideal para o estilo urbano contemporâneo.',
                'short_description': 'Calça cargo preta multibolsos',
                'price': 259.90,
                'category_slug': 'pants',
                'stock_quantity': 25,
                'is_featured': True,
                'variants': [
                    {'size': 'M', 'color': 'Preto', 'color_hex': '#000000', 'stock': 8, 'sku': 'PNT-CAR-BLK-M'},
                    {'size': 'G', 'color': 'Preto', 'color_hex': '#000000', 'stock': 10, 'sku': 'PNT-CAR-BLK-G'},
                    {'size': 'GG', 'color': 'Preto', 'color_hex': '#000000', 'stock': 7, 'sku': 'PNT-CAR-BLK-GG'},
                ]
            },
            {
                'name': 'CAP PACKS LOGO NEON',
                'slug': 'cap-packs-logo-neon',
                'description': 'Boné preto com logo PACKS em verde neon. Ajuste regulável e design exclusivo.',
                'short_description': 'Boné preto com logo neon',
                'price': 89.90,
                'original_price': 119.90,
                'category_slug': 'accessories',
                'stock_quantity': 40,
                'is_on_sale': True,
                'variants': [
                    {'size': 'Único', 'color': 'Preto/Neon', 'color_hex': '#000000', 'stock': 40, 'sku': 'CAP-LOG-NEO-U'},
                ]
            },
            {
                'name': 'TEE PACKS GRAPHIC WHITE',
                'slug': 'tee-packs-graphic-white',
                'description': 'Camiseta branca com estampa gráfica exclusiva PACKS. Design artístico e moderno.',
                'short_description': 'Camiseta branca com estampa gráfica',
                'price': 199.90,
                'category_slug': 'tees',
                'stock_quantity': 35,
                'is_new': True,
                'variants': [
                    {'size': 'P', 'color': 'Branco', 'color_hex': '#FFFFFF', 'stock': 5, 'sku': 'TEE-GRA-WHT-P'},
                    {'size': 'M', 'color': 'Branco', 'color_hex': '#FFFFFF', 'stock': 10, 'sku': 'TEE-GRA-WHT-M'},
                    {'size': 'G', 'color': 'Branco', 'color_hex': '#FFFFFF', 'stock': 12, 'sku': 'TEE-GRA-WHT-G'},
                    {'size': 'GG', 'color': 'Branco', 'color_hex': '#FFFFFF', 'stock': 6, 'sku': 'TEE-GRA-WHT-GG'},
                    {'size': 'XG', 'color': 'Branco', 'color_hex': '#FFFFFF', 'stock': 2, 'sku': 'TEE-GRA-WHT-XG'},
                ]
            }
        ]
        
        for product_data in products_data:
            # Buscar categoria
            category = Category.query.filter_by(slug=product_data['category_slug']).first()
            
            # Criar produto
            product = Product(
                name=product_data['name'],
                slug=product_data['slug'],
                description=product_data['description'],
                short_description=product_data['short_description'],
                price=product_data['price'],
                original_price=product_data.get('original_price'),
                category_id=category.id,
                stock_quantity=product_data['stock_quantity'],
                is_new=product_data.get('is_new', False),
                is_on_sale=product_data.get('is_on_sale', False),
                is_featured=product_data.get('is_featured', False),
                meta_title=f"{product_data['name']} - PACKS Streetwear",
                meta_description=product_data['short_description']
            )
            
            db.session.add(product)
            db.session.flush()  # Para obter o ID do produto
            
            # Criar variações
            for variant_data in product_data['variants']:
                variant = ProductVariant(
                    product_id=product.id,
                    size=variant_data['size'],
                    color=variant_data['color'],
                    color_hex=variant_data['color_hex'],
                    stock_quantity=variant_data['stock'],
                    sku=variant_data['sku']
                )
                db.session.add(variant)
            
            # Criar imagem placeholder
            image = ProductImage(
                product_id=product.id,
                image_url=f'/api/placeholder/400/500?text={product_data["name"].replace(" ", "+")}',
                alt_text=product_data['name'],
                is_primary=True,
                sort_order=0
            )
            db.session.add(image)
        
        db.session.commit()
        print("✅ Banco de dados populado com sucesso!")
        print(f"📦 {len(categories)} categorias criadas")
        print(f"🛍️ {len(products_data)} produtos criados")

if __name__ == '__main__':
    seed_database()

