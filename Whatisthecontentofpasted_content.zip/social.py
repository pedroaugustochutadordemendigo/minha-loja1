from flask import Blueprint, request, jsonify
import requests
from datetime import datetime, timedelta

social_bp = Blueprint('social', __name__)

# Configurações do Instagram Basic Display API
INSTAGRAM_ACCESS_TOKEN = "YOUR_INSTAGRAM_ACCESS_TOKEN"  # Substituir por token real
INSTAGRAM_BASE_URL = "https://graph.instagram.com"

@social_bp.route('/social/instagram/feed', methods=['GET'])
def get_instagram_feed():
    """Obter feed do Instagram da marca"""
    try:
        limit = request.args.get('limit', 12, type=int)
        
        # Em produção, usar API real do Instagram
        # Por enquanto, retornar dados simulados
        mock_posts = [
            {
                'id': '1',
                'media_type': 'IMAGE',
                'media_url': 'https://picsum.photos/400/400?random=1',
                'thumbnail_url': 'https://picsum.photos/400/400?random=1',
                'caption': 'Nova coleção PACKS chegando! 🔥 #streetwear #packs #novacoleção',
                'permalink': 'https://instagram.com/p/example1',
                'timestamp': '2025-07-15T10:00:00+0000',
                'like_count': 245,
                'comments_count': 18
            },
            {
                'id': '2',
                'media_type': 'IMAGE',
                'media_url': 'https://picsum.photos/400/400?random=2',
                'thumbnail_url': 'https://picsum.photos/400/400?random=2',
                'caption': 'Look do dia com nossa TEE LOGO BLACK ⚡ #ootd #streetstyle',
                'permalink': 'https://instagram.com/p/example2',
                'timestamp': '2025-07-14T15:30:00+0000',
                'like_count': 189,
                'comments_count': 12
            },
            {
                'id': '3',
                'media_type': 'VIDEO',
                'media_url': 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
                'thumbnail_url': 'https://picsum.photos/400/400?random=3',
                'caption': 'Behind the scenes da nossa nova campanha 🎬 #bts #packs',
                'permalink': 'https://instagram.com/p/example3',
                'timestamp': '2025-07-13T12:15:00+0000',
                'like_count': 312,
                'comments_count': 25
            },
            {
                'id': '4',
                'media_type': 'IMAGE',
                'media_url': 'https://picsum.photos/400/400?random=4',
                'thumbnail_url': 'https://picsum.photos/400/400?random=4',
                'caption': 'HOODIE URBAN WHITE em destaque! Conforto e estilo 💫',
                'permalink': 'https://instagram.com/p/example4',
                'timestamp': '2025-07-12T18:45:00+0000',
                'like_count': 156,
                'comments_count': 8
            },
            {
                'id': '5',
                'media_type': 'IMAGE',
                'media_url': 'https://picsum.photos/400/400?random=5',
                'thumbnail_url': 'https://picsum.photos/400/400?random=5',
                'caption': 'Street vibes com nossa CARGO PANTS 🖤 #streetwear #cargo',
                'permalink': 'https://instagram.com/p/example5',
                'timestamp': '2025-07-11T14:20:00+0000',
                'like_count': 203,
                'comments_count': 15
            },
            {
                'id': '6',
                'media_type': 'IMAGE',
                'media_url': 'https://picsum.photos/400/400?random=6',
                'thumbnail_url': 'https://picsum.photos/400/400?random=6',
                'caption': 'CAP LOGO NEON - o acessório que faltava no seu look! ⚡',
                'permalink': 'https://instagram.com/p/example6',
                'timestamp': '2025-07-10T11:30:00+0000',
                'like_count': 178,
                'comments_count': 9
            }
        ]
        
        # Limitar número de posts
        posts = mock_posts[:limit]
        
        return jsonify({
            'success': True,
            'posts': posts,
            'total': len(posts)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao obter feed do Instagram: {str(e)}'
        }), 500

def get_instagram_posts_real(access_token, limit=12):
    """Função para obter posts reais do Instagram (para uso em produção)"""
    try:
        url = f"{INSTAGRAM_BASE_URL}/me/media"
        
        params = {
            'fields': 'id,media_type,media_url,thumbnail_url,caption,permalink,timestamp,like_count,comments_count',
            'limit': limit,
            'access_token': access_token
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            return data.get('data', [])
        else:
            print(f"Erro na API do Instagram: {response.text}")
            return []
            
    except Exception as e:
        print(f"Erro ao buscar posts do Instagram: {str(e)}")
        return []

@social_bp.route('/social/instagram/profile', methods=['GET'])
def get_instagram_profile():
    """Obter informações do perfil do Instagram"""
    try:
        # Dados simulados do perfil
        profile_data = {
            'id': 'packs_streetwear',
            'username': 'packs_streetwear',
            'name': 'PACKS Streetwear',
            'biography': 'Streetwear autêntico para quem vive a cultura urbana 🔥\n📍 Monte Belo, MG\n🛒 Loja online',
            'website': 'https://packs.com.br',
            'profile_picture_url': 'https://picsum.photos/150/150?random=profile',
            'followers_count': 15420,
            'following_count': 892,
            'media_count': 156
        }
        
        return jsonify({
            'success': True,
            'profile': profile_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao obter perfil do Instagram: {str(e)}'
        }), 500

@social_bp.route('/social/newsletter/subscribe', methods=['POST'])
def subscribe_newsletter():
    """Inscrever email na newsletter"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Dados não fornecidos'
            }), 400
        
        email = data.get('email', '').strip().lower()
        
        if not email:
            return jsonify({
                'success': False,
                'error': 'Email é obrigatório'
            }), 400
        
        # Validação básica de email
        if '@' not in email or '.' not in email:
            return jsonify({
                'success': False,
                'error': 'Email inválido'
            }), 400
        
        # Em produção, salvar no banco de dados e integrar com serviço de email
        # Por enquanto, apenas simular sucesso
        
        # TODO: Implementar integração com Mailchimp, SendGrid, etc.
        # TODO: Salvar no banco de dados
        
        return jsonify({
            'success': True,
            'message': 'Email cadastrado com sucesso! Você receberá nossas novidades em primeira mão.'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao cadastrar email: {str(e)}'
        }), 500

@social_bp.route('/social/contact', methods=['POST'])
def send_contact_message():
    """Enviar mensagem de contato"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Dados não fornecidos'
            }), 400
        
        required_fields = ['name', 'email', 'subject', 'message']
        
        for field in required_fields:
            if not data.get(field, '').strip():
                return jsonify({
                    'success': False,
                    'error': f'Campo obrigatório: {field}'
                }), 400
        
        # Em produção, enviar email para a empresa
        # Por enquanto, apenas simular sucesso
        
        contact_data = {
            'name': data['name'].strip(),
            'email': data['email'].strip().lower(),
            'subject': data['subject'].strip(),
            'message': data['message'].strip(),
            'timestamp': datetime.now().isoformat()
        }
        
        # TODO: Implementar envio de email
        # TODO: Salvar no banco de dados
        
        print(f"📧 Nova mensagem de contato de {contact_data['name']} ({contact_data['email']})")
        print(f"Assunto: {contact_data['subject']}")
        print(f"Mensagem: {contact_data['message']}")
        
        return jsonify({
            'success': True,
            'message': 'Mensagem enviada com sucesso! Entraremos em contato em breve.'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao enviar mensagem: {str(e)}'
        }), 500

@social_bp.route('/social/reviews', methods=['GET'])
def get_product_reviews():
    """Obter avaliações de produtos"""
    try:
        product_id = request.args.get('product_id', type=int)
        limit = request.args.get('limit', 10, type=int)
        
        # Dados simulados de avaliações
        mock_reviews = [
            {
                'id': 1,
                'product_id': product_id or 1,
                'customer_name': 'João Silva',
                'rating': 5,
                'title': 'Produto excelente!',
                'comment': 'Qualidade incrível, tecido macio e o tamanho veio certinho. Recomendo!',
                'verified_purchase': True,
                'created_at': '2025-07-10T14:30:00',
                'helpful_count': 12
            },
            {
                'id': 2,
                'product_id': product_id or 1,
                'customer_name': 'Maria Santos',
                'rating': 4,
                'title': 'Muito bom',
                'comment': 'Gostei bastante do produto, só achei que poderia ter mais opções de cor.',
                'verified_purchase': True,
                'created_at': '2025-07-08T16:45:00',
                'helpful_count': 8
            },
            {
                'id': 3,
                'product_id': product_id or 1,
                'customer_name': 'Pedro Costa',
                'rating': 5,
                'title': 'Superou expectativas',
                'comment': 'Design incrível e qualidade premium. Vale cada centavo!',
                'verified_purchase': True,
                'created_at': '2025-07-05T10:20:00',
                'helpful_count': 15
            }
        ]
        
        # Filtrar por produto se especificado
        if product_id:
            reviews = [r for r in mock_reviews if r['product_id'] == product_id]
        else:
            reviews = mock_reviews
        
        # Limitar resultados
        reviews = reviews[:limit]
        
        # Calcular estatísticas
        if reviews:
            total_reviews = len(reviews)
            average_rating = sum(r['rating'] for r in reviews) / total_reviews
            rating_distribution = {
                '5': len([r for r in reviews if r['rating'] == 5]),
                '4': len([r for r in reviews if r['rating'] == 4]),
                '3': len([r for r in reviews if r['rating'] == 3]),
                '2': len([r for r in reviews if r['rating'] == 2]),
                '1': len([r for r in reviews if r['rating'] == 1])
            }
        else:
            total_reviews = 0
            average_rating = 0
            rating_distribution = {'5': 0, '4': 0, '3': 0, '2': 0, '1': 0}
        
        return jsonify({
            'success': True,
            'reviews': reviews,
            'statistics': {
                'total_reviews': total_reviews,
                'average_rating': round(average_rating, 1),
                'rating_distribution': rating_distribution
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao obter avaliações: {str(e)}'
        }), 500

