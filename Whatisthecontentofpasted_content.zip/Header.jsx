import { useState } from 'react'
import { Search, User, Heart, ShoppingCart, Menu, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [cartCount] = useState(0)

  const navItems = [
    { name: 'Home', href: '#' },
    { name: 'Produtos', href: '#produtos' },
    { name: 'Novidades', href: '#novidades' },
    { name: 'Coleções', href: '#colecoes' },
    { name: 'Ofertas', href: '#ofertas' }
  ]

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-effect border-b border-white/10">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <h1 className="logo-packs text-white">packs</h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-white hover:text-primary transition-colors duration-300 font-medium"
              >
                {item.name}
              </a>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Search */}
            <div className="relative">
              {isSearchOpen ? (
                <div className="flex items-center">
                  <input
                    type="text"
                    placeholder="Buscar produtos..."
                    className="bg-card border border-white/20 rounded-lg px-4 py-2 text-white placeholder-gray-400 w-64 focus:outline-none focus:border-primary transition-colors"
                    autoFocus
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsSearchOpen(false)}
                    className="ml-2 text-white hover:text-primary"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              ) : (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsSearchOpen(true)}
                  className="text-white hover:text-primary"
                >
                  <Search className="h-5 w-5" />
                </Button>
              )}
            </div>

            {/* User Account */}
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:text-primary"
            >
              <User className="h-5 w-5" />
            </Button>

            {/* Favorites */}
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:text-primary"
            >
              <Heart className="h-5 w-5" />
            </Button>

            {/* Cart */}
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:text-primary relative"
            >
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium">
                  {cartCount}
                </span>
              )}
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-white/10">
            <nav className="flex flex-col space-y-4">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-white hover:text-primary transition-colors duration-300 font-medium"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </a>
              ))}
            </nav>
            
            {/* Mobile Search */}
            <div className="mt-4 pt-4 border-t border-white/10">
              <input
                type="text"
                placeholder="Buscar produtos..."
                className="w-full bg-card border border-white/20 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:border-primary transition-colors"
              />
            </div>

            {/* Mobile Actions */}
            <div className="flex items-center justify-around mt-4 pt-4 border-t border-white/10">
              <Button variant="ghost" size="sm" className="text-white hover:text-primary">
                <User className="h-5 w-5" />
                <span className="ml-2">Conta</span>
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-primary">
                <Heart className="h-5 w-5" />
                <span className="ml-2">Favoritos</span>
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-primary relative">
                <ShoppingCart className="h-5 w-5" />
                <span className="ml-2">Carrinho</span>
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium">
                    {cartCount}
                  </span>
                )}
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}

export default Header

